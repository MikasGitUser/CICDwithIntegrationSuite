import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def body = message.getBody(String);
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        messageLog.setStringProperty("CustomLogProperty", "YourValue");
        messageLog.addAttachmentAsString("CustomAttachment", body, "text/plain");
    }
    return message;
}
