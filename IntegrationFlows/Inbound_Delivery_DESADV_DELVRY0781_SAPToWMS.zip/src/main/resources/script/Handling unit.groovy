import com.sap.it.api.mapping.* // Import the required SAP CPI mapping classes

def String mapD_7075(String HIPOS, MappingContext context) { 
    // Check if HIPOS is blank
    if (HIPOS == null || HIPOS.trim().isEmpty()) {
        return "3"; // Return "3" if HIPOS is blank (null or empty)
    } else {
        return "2"; // Return "2" if HIPOS is not blank
    }
}
