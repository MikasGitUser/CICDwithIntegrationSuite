import com.sap.it.api.mapping.*
import java.util.concurrent.ConcurrentHashMap

// Keeps count of each EXIDV's occurrences
@Field static Map<String, Integer> exidvSequenceMap = new ConcurrentHashMap<>()

def String map7164FromEXIDV(String EXIDV, MappingContext context) {
    if (EXIDV == null || EXIDV.trim().isEmpty()) {
        return "1"  // Optional: Default to 1 or blank
    }

    String exidvKey = EXIDV.trim()
    Integer sequence = exidvSequenceMap.getOrDefault(exidvKey, 0) + 1
    exidvSequenceMap.put(exidvKey, sequence)

    return String.valueOf(sequence)
}
