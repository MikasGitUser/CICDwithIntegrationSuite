import com.sap.gateway.ip.core.customdev.util.Message;

// Function to process the message
def Message processData(Message message) {

    // Retrieve the original message payload as a string
    String originalPayload = message.getBody(String);

    // Ensure the payload is properly encoded in UTF-8
    byte[] utf8Bytes = originalPayload.getBytes("ISO-8859-1"); // Convert from source encoding
    String utf8Payload = new String(utf8Bytes, "UTF-8");       // Convert to UTF-8

    // Set the corrected payload back to the message body
    message.setBody(utf8Payload);

    // Return the updated message
    return message;
}
