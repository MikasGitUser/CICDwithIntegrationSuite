import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def body = message.getBody(String)

    // Split the EDI message on the segment terminator (')
    def segments = body.split("'")

    // Optional: trim whitespace and ignore empty segments
    def formatted = segments.findAll { it?.trim() }.collect { it.trim() + "'" }

    // Join with newline for readability
    def result = formatted.join('\n')

    message.setBody(result)
    return message
}
