import com.sap.it.api.mapping.* // Import SAP CPI mapping classes

def String mapD_7224(String HIPOS, String ANZPK, MappingContext context) {
    // Check if HIPOS is blank or null
    if (HIPOS == null || HIPOS.trim().isEmpty()) {
        return "";  // If HIPOS is blank, return an empty string instead of null
    } else {
        // If HIPOS is not blank, return ANZPK or an empty string if ANZPK is null
        return ANZPK != null ? ANZPK : ""; 
    }
}