import com.sap.it.api.mapping.*;

def void formatMatnr(String[] matnr, Output output, MappingContext context) {
    if (matnr[0] != null) {
        String trimmedValue = matnr[0].trim()
        String formattedValue
        
        // Check if the value is purely numeric
        if (trimmedValue.matches("\\d+")) {
            formattedValue = String.format("%018d", Long.parseLong(trimmedValue))
        } else {
            formattedValue = String.format("%018s", trimmedValue) // Left-pad non-numeric values
        }
        
        output.addValue(formattedValue)
    } else {
        output.addValue("000000000000000000") // Default fallback
    }
}
