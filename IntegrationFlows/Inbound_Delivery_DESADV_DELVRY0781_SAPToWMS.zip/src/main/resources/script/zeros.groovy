import com.sap.it.api.mapping.*

def void removeLeadingZeros(String[] POBJID, Output output, MappingContext context) {
    String pobjidValue = POBJID[0] ?: ""  // Handle null safely
    String cleanedValue = pobjidValue.replaceFirst("^0+", "")  // Remove leading zeros
    
    // Ensure numeric conversion (if applicable)
    cleanedValue = cleanedValue.isNumber() ? cleanedValue.toInteger().toString() : cleanedValue

    output.addValue(cleanedValue)
}
