import com.sap.it.api.mapping.* // Import the required SAP CPI mapping classes

def String mapD_7075(String CHARG, MappingContext context) {
    // Check if EXIDV has any value (not null and not empty)
    if (CHARG != null && !CHARG.trim().isEmpty()) {
        return "2"; // Pass "1" if EXIDV has any value
    } else {
        return ""; // Return an empty string if EXIDV is null or empty
    }
}
