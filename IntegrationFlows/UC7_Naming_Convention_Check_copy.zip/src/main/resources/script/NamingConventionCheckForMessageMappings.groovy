import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def regexMessageMappings = message.getProperty("NCRegex_MessageMappings")

    if (!regexMessageMappings) {
        throw new Exception("Property 'NCRegex_MessageMappings' has no value")
    }

    def body = message.getBody(String)
    def xml = new XmlSlurper().parseText(body)

    def MessageMappingNames = xml.Name.collect { it.text() }

    def csvLines = MessageMappingNames.collect { name ->
        def valid = (name ==~ regexMessageMappings) ? "VALID" : "INVALID"
        return "MessageMapping,${name},${valid}"
    }

    message.setBody(csvLines.join("\n"))

    return message
}
