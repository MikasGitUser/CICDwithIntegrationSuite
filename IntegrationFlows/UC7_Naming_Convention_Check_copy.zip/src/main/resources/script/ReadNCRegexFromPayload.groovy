import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def body = message.getBody(String)

    def sections = [
        "Packages"           : "NCRegex_Packages",
        "Integration Flows"  : "NCRegex_IntegrationFlows",
        "Message Mappings"   : "NCRegex_MessageMappings",
        "Value Mappings"     : "NCRegex_ValueMappings",
        "Script Collections" : "NCRegex_ScriptCollections"
    ]

    sections.each { section, propertyName ->
       
        def pattern = ~/(?m)^${section}:\s*(.+)?$/
        def matcher = pattern.matcher(body)
        
        if (matcher.find()) {
            def regexValue = matcher.group(1)?.trim()
            if (regexValue) {
                message.setProperty(propertyName, regexValue)
            } else {
                message.setProperty(propertyName, "")
            }
        }
    }

    return message
}
