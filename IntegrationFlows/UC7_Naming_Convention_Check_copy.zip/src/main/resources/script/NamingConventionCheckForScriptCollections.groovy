import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def regexScriptCollections = message.getProperty("NCRegex_ScriptCollections")

    if (!regexScriptCollections) {
        throw new Exception("Property 'NCRegex_ScriptCollections' has no value")
    }

    def body = message.getBody(String)
    def xml = new XmlSlurper().parseText(body)

    def ScriptCollectionNames = xml.Name.collect { it.text() }

    def csvLines = ScriptCollectionNames.collect { name ->
        def valid = (name ==~ regexScriptCollections) ? "VALID" : "INVALID"
        return "ScriptCollection,${name},${valid}"
    }

    message.setBody(csvLines.join("\n"))

    return message
}
