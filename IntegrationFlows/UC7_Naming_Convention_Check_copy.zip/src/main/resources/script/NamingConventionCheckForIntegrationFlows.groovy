import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def regexIntegrationFlows = message.getProperty("NCRegex_IntegrationFlows")

    if (!regexIntegrationFlows) {
        throw new Exception("Property 'NCRegex_IntegrationFlows' has no value")
    }

    def body = message.getBody(String)
    def xml = new XmlSlurper().parseText(body)

    def IntegrationFlowNames = xml.Name.collect { it.text() }

    def csvLines = IntegrationFlowNames.collect { name ->
        def valid = (name ==~ regexIntegrationFlows) ? "VALID" : "INVALID"
        return "IntegrationFlow,${name},${valid}"
    }

    message.setBody(csvLines.join("\n"))

    return message
}
