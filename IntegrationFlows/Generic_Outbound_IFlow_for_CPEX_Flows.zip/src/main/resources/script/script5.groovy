import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;

def Message processData(Message message) {

    def service = ITApiFactory.getApi(PartnerDirectoryService.class, null); 
    if (service == null){
        throw new IllegalStateException("Partner Directory Service not found");
    }
    
    // Get Partner ID from the Property
    def properties = message.getProperties();
    
    def Pid = properties.get("Receiver");
    if (Pid == null){
        throw new IllegalStateException("Property with name \"Receiver\" not found in sent message");   
    }
    // Get parameter IDOC_Address
    def IDOCAddress = service.getParameter("IDOC_Address", Pid , String.class);
    if (IDOCAddress == null){
        throw new IllegalStateException("Partner ID " + Pid + " not found or \"IDOC_Address\" parameter not found in the Partner Directory");      
    }
    message.setProperty("IDOC_Address", IDOCAddress);

    // Get parameter IDOC_Mapping
    def IDOCMapping = service.getParameter("IDOC_Mapping", Pid , String.class);
    if (IDOCMapping == null){
        throw new IllegalStateException("Partner ID " + Pid + " not found or \"IDOC_Mapping\" parameter not found in the Partner Directory");      
    }
    message.setProperty("IDOC_Mapping", IDOCMapping);

    return message;
}
