import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.pd.BinaryData;
import com.sap.it.api.ITApiFactory;

def Message processData(Message message) {

    def service = ITApiFactory.getApi(PartnerDirectoryService.class, null); 
    if (service == null){
        throw new IllegalStateException("Partner Directory Service not found");
    }
    
    // Get Partner ID from the Property
    def properties = message.getProperties(); 
    def Pid = properties.get("Receiver");
    if (Pid == null){
        throw new IllegalStateException("Property with name \"Receiver\" not found in sent message");   
    }
    // Get parameter SOAP_Address
    def SOAPAddress = service.getParameter("SOAP_Address", Pid , String.class);
    if (SOAPAddress == null){
        throw new IllegalStateException("Partner ID " + Pid + " not found or \"SOAP_Address\" parameter not found in the Partner Directory");      
    }
    // Set property SOAP_Address
    message.setProperty("SOAP_Address", SOAPAddress);

    // Get parameter SOAP_Mapping
    def SOAPMapping = service.getParameter("SOAP_Mapping", Pid , String.class);
    if (SOAPMapping == null){
        throw new IllegalStateException("Partner ID " + Pid + " not found or \"SOAP_Mapping\" parameter not found in the Partner Directory");      
    }
    // Set property SOAP_Address
    message.setProperty("SOAP_Mapping", SOAPMapping);
    
    // Get parameter SOAP_XSLCondition
    //def SOAPXSLCondition = service.getParameter("SOAP_XSLCondition", Pid , BinaryData.class);
    //if (SOAPXSLCondition == null){
    //    throw new IllegalStateException("Partner ID " + Pid + " not found or \"SOAP_XSLCondition\" parameter not found in the Partner Directory");      
    //}
    // Set Header SOAP_XSLCondition
    message.setHeader("SOAP_XSLCondition", "pd:"+ Pid +":SOAP_XSLCondition:Binary");

    return message;
}
