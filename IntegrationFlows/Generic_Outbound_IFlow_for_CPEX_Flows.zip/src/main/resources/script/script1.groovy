import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;

def Message processData(Message message) {

    def service = ITApiFactory.getApi(PartnerDirectoryService.class, null); 
    if (service == null){
        throw new IllegalStateException("Partner Directory Service not found");
    }
    
    // Get Partner ID from the Property
    def properties = message.getProperties(); 
    def Pid = properties.get("Receiver");
    if (Pid == null){
        throw new IllegalStateException("Property with name \"Receiver\" not found in sent message");   
    }
    // Get parameter AdapterType 
    def ReceiverAdapterType = service.getParameter("AdapterType", Pid , String.class);
    if (ReceiverAdapterType == null){
        throw new IllegalStateException("Partner ID " + Pid + " not found or \"AdapterType\" parameter not found in the Partner Directory");      
    }
    message.setProperty("ReceiverAdapterType", ReceiverAdapterType);
    message.setBody(properties.get("InputPayload"));
    return message;
}
