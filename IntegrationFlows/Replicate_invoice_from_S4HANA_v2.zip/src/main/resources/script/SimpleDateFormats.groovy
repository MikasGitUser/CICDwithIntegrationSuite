import com.sap.it.api.mapping.*;
import groovy.time.*
import java.text.SimpleDateFormat 
import java.util.Date
def String timeZoneUTC(String arg1){
     //target format
     def df = "yyyyMMddHHmmss"
    //input format
     SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss zzz");
     Date mTimeStamp = format.parse(arg1);
	return mTimeStamp.format(df) 
}