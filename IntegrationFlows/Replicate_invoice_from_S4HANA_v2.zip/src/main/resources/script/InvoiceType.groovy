import com.sap.it.api.mapping.*;

def String InvoiceType(String id){

    def output = 'ZF2';

    if(id == 'ZF2' || id == 'ZL2' || id == 'ZS2'){

        output = '843640000'

    }else if(id == 'ZG2' || id == 'ZS1'){

        output = '843640001'

    }

    return output;

}