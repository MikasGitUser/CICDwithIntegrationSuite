import com.sap.it.api.mapping.*;
def String removeLeadingZeros(String id){
// This function will remove all leading zeros if the input string is non-alphaneumeric 
	int idAsInt = 0;
		try {
			 idAsInt = Integer.parseInt(id);
		}
		catch (java.lang.NumberFormatException e)
		{
		// if id is not numeric, just return it
			return id ;
		}
		return String.valueOf(idAsInt); 
}