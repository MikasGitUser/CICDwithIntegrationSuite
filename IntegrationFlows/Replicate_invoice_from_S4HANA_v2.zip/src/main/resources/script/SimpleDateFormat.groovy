import com.sap.it.api.mapping.*;
import groovy.time.*
import java.text.SimpleDateFormat 
import java.util.Date
import static java.util.Calendar.*;
def String timeZoneUTC(String arg1){
     def df = "yyyy-MM-dd'T'HH:mm:ss"
     SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-ddHH:mm:ss");
     format.setTimeZone(TimeZone.getTimeZone("Europe/Berlin"));
     Date mTimeStamp = format.parse(arg1);
	return mTimeStamp.format(df); 
}