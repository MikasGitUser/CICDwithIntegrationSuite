import com.sap.it.api.mapping.*;
 
 
def String getProperty(String P1, MappingContext context) {
         String value1 = context.getProperty(P1);
         return value1;
}