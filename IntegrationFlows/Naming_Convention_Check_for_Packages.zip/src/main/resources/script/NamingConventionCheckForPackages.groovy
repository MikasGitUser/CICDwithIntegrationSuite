import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def regexPackages = message.getProperty("NCRegex_Packages")

    if (!regexPackages) {
        throw new Exception("Property 'NCRegex_Packages' has no value")
    }

    def body = message.getBody(String)
    def xml = new XmlSlurper().parseText(body)

    def packageNames = xml.Name.collect { it.text() }

    def csvLines = packageNames.collect { name ->
        def valid = (name ==~ regexPackages) ? "VALID" : "INVALID"
        return "Package,${name},${valid}"
    }

    message.setBody(csvLines.join("\n"))

    return message
}
