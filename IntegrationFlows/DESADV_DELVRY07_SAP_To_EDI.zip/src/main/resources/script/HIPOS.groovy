import com.sap.it.api.mapping.*

// UDF to be used in Message Mapping
def String mapD_7224FromHipos(String HIPOS, String ANZPK, MappingContext context) {
    if (HIPOS != null && !hipos.trim().isEmpty()) {
        return ANZPK != null ? anzpk.trim() : ""
    } else {
        return ""  // or null if you want to omit the field completely
    }
}