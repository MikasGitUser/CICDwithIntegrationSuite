import com.sap.gateway.ip.core.customdev.util.Message

def processData(Message message) {
    def edifactMessage = message.getBody(String)

    // Pattern to match CPS segments while preserving variable `+` occurrences before the last value
    def cpsPattern = /CPS\+(\+\+)*(\d+)'/

    // Initialize the sequence counter
    int counter = 1

    // Replace only the sequence number while keeping `+++3` or `++3` structure intact
    def updatedMessage = edifactMessage.replaceAll(cpsPattern) { match ->
        def plusSigns = match[1] ?: '' // Capture any existing `+` signs
        def value = match[2] // Capture the final value
        return "CPS+${counter++}${plusSigns}${value}'" // Preserve original format
    }

    // Set the updated message back in the body
    message.setBody(updatedMessage)
    return message
}
