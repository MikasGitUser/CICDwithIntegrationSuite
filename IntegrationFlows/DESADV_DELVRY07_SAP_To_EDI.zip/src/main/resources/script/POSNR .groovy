import com.sap.it.api.mapping.* // Import the required SAP CPI mapping classes

def String mapD_1082(String HIPOS, String POSNR, MappingContext context) {
    if (HIPOS == null || HIPOS.trim().isEmpty()) {
        return POSNR; // If HIPOS is blank, return POSNR
    } else {
        return POSNR; // If HIPOS is not blank, return POSNR
    }
}