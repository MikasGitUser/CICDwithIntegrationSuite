/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */

// Assumption for below code is that only one S_MSG will come in the source message. 

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;

def Message processData(Message message) {

    def M_850 = new XmlParser().parseText(message.getBody(String)) //parse xml, as slurper do not allow to modify the stream
    int splitBuffer = 70; //nb of characters by line in the buffer
    int i; //iterator index for M_850/G_N9/S_MSG context while creating nodes

    //Check if anything needs to be split by refering to split buffer
    if(M_850.G_N9.S_MSG.D_933.text().length() > splitBuffer){
        
        //Split using regex is more elegant then loop:   .split("(?<=\\G.{70})")
        String [] splitTexts = M_850.G_N9.S_MSG.D_933.text().split("(?<=\\G.{" + splitBuffer.toString() + "})")  
        
        //Clean up raw content within xml context given
        def nodesToDelete =  M_850.G_N9.S_MSG //removes S_MSG and child nodes
        nodesToDelete.each { node ->
            node.parent().remove(node)
        }

        //Add split lines
        i=0
        for( String splitText : splitTexts ){
            new Node(M_850.G_N9[0], 'S_MSG') //create 1...unbound S_MSG dynamically under a static first occurence of node G_N9
            new Node(M_850.G_N9.S_MSG[i], 'D_933', splitText) //create D_933 element under S_MSG field and assign a value from the splitText array
            i++
        }

    }

    //serialize body
    message.setBody(XmlUtil.serialize(M_850))
    return message;

}