import com.sap.it.api.mapping.*

/**
 * Extracts the numeric value from the RFF+CO:<numeric_value>' segment.
 * It expects the entire RFF segment and returns the numeric value.
 */
def extractNumericValueFromRFF(String rffSegment, Output output, MappingContext context) {
    // Regular expression to match the RFF+CO:<numeric_value>' format
    def matcher = rffSegment =~ /RFF\+CO:(\d+)'/
    
    if (matcher.find()) {
        // Extract and add the numeric value to the output
        output.addValue(matcher.group(1))
    } else {
        output.addValue("")
    }
}
