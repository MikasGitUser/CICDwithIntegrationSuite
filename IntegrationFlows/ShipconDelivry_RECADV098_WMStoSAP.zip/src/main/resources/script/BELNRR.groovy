import com.sap.it.api.mapping.*

def void mapRffSegmentForCO(String D_1153, String D_1154, Output output, MappingContext context) {
    if (D_1153?.trim() == "CO" && D_1154?.trim()) {
        def rffSegment = "RFF+CO:${D_1154.trim()}'"
        output.addValue(rffSegment)
    }
}