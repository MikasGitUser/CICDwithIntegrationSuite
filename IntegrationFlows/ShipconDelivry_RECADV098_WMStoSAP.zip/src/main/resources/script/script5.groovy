import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlParser
import groovy.xml.XmlUtil

def processData(Message message) {
    def body = message.getBody(String) // Retrieve XML payload as string
    def xml = new XmlParser().parseText(body) // Parse XML

    // Find E1EDL24 elements where LFIMG = 0.000 and remove them
    def parentNode = xml.IDOC.E1EDL20[0]
    parentNode.children().removeAll { 
        it.name() == 'E1EDL24' && it.LFIMG.text() == '0.000' 
    }

    // Convert back to XML string and set it as the response body
    def outputXml = XmlUtil.serialize(xml)
    message.setBody(outputXml)

    return message
}
