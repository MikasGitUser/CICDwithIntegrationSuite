import groovy.xml.XmlParser
import groovy.xml.XmlUtil

def inputXml = message.getBody(java.lang.String)
def xmlParser = new XmlParser(false, false) // Disable validation and namespace handling
def root = xmlParser.parseText(inputXml)

// Iterate and remove unwanted E1EDL24 elements
root.IDOC.E1EDL20.each { delivery ->
    delivery.children().removeIf { it.name() == 'E1EDL24' && it.LFIMG.text() == '0.000' }
}

// Convert back to XML
def outputXml = XmlUtil.serialize(root)
message.setBody(outputXml)
