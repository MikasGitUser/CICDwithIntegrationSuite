import com.sap.it.api.mapping.*

/**
 * This function extracts the numeric value from the RFF+CO:<numeric_value>' segment.
 * It expects the entire RFF segment and returns the numeric value.
 */
def void extractNumericValueFromRFF(String rffSegment, Output output, MappingContext context) {
    // Regular expression to match the RFF+CO:<numeric_value>' format
    def matcher = rffSegment =~ /RFF\+CO:(\d+)'/
    
    // If the segment matches the RFF+CO:<numeric_value>' pattern
    if (matcher.find()) {
        // Extract the numeric value from the first group of the match
        def numericValue = matcher.group(1)
        
        // Add the numeric value to the output
        output.addValue(numericValue)
    } else {
        // If the segment doesn't match, no output will be generated
        output.addValue("")
    }
}
