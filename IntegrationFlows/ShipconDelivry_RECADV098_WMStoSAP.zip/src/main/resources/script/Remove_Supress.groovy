import com.sap.it.api.mapping.*;

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

def void removeSuppress(String[] values, Output output, MappingContext context) {
    values.findAll { v -> // Filter out only non-suppressed and non-blank values
        return v != null && v.trim() != '' && !output.isSuppress(v)  // Exclude null, blank, and suppressed values
    }.each { v ->  // Iterate over the filtered list
        output.addValue(v)  // Add each non-suppressed value to the output
    }
}
