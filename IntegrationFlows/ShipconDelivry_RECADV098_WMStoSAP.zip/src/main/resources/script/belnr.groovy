import com.sap.it.api.mapping.*

def void mapCoToRff(String qualifier, String value, Output output, MappingContext context) {
    if (qualifier == "CO" && value) {
        def rffSegment = "RFF+CO:${value}'"
        output.addValue(rffSegment)
    }
}
