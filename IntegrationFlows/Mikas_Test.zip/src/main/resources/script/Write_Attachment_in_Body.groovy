import com.sap.gateway.ip.core.customdev.util.Message
import java.util.regex.Pattern

Message processData(Message message) {

    // --- 1️⃣ Dateinamen aus Header lesen ---
    def contentDisposition = message.getHeaders().get("content-disposition")

    def fileName = "attachment.zip" // Default-Fallback

    if (contentDisposition != null) {
        def matcher = Pattern.compile("filename=\"?([^\";]+)\"?").matcher(contentDisposition)
        if (matcher.find()) {
            fileName = matcher.group(1)
        }
    }

    // --- 2️⃣ Attachment auslesen ---
     def attachment = message.getAttachment(fileName)
    if (attachment == null || attachment.isEmpty()) {
        throw new Exception("No attachment found in message!")
    }


    // --- 3️⃣ Binary Content in den Body schreiben ---
    def inputStream = attachment.getInputStream()
    def bytes = inputStream.bytes
    inputStream.close()

    message.setBody(bytes)
    message.setHeader("FileName", fileName)

    return message
}
