import com.sap.gateway.ip.core.customdev.util.Message
import java.util.Base64

def Message processData(Message message) {

    def body = message.getBody(java.io.InputStream)
    byte[] bytes = body.bytes
    def encoded = Base64.getEncoder().encodeToString(bytes)

    def filePath = "artifacts/my-iflow.zip"
    def repoOwner = "your-username"
    def repoName = "your-repo"
    def gitToken = "ghp_xxxxxxxxxxxxxxxx" // Use securely from secure parameter

    def payload = [
        message: "Upload CPI IFlow Artifact",
        content: encoded
    ]

    def apiUrl = "https://api.github.com/repos/${repoOwner}/${repoName}/contents/${filePath}"
    message.setHeader("Authorization", "Bearer ${gitToken}")
    message.setHeader("Content-Type", "application/json")
    message.setHeader("CamelHttpMethod", "PUT")
    message.setProperty("GitHubApiUrl", apiUrl)
    message.setBody(new groovy.json.JsonBuilder(payload).toString())

    return message
}
