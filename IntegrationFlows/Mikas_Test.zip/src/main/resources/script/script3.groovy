import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
 
def Message processData(Message message) {
    // Set the message body to an empty string
    message.setBody("")
    return message
}