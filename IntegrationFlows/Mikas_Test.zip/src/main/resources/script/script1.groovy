import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    
// Get the body as InputStream and convert it to a string

    def bodyStream = message.getBody(InputStream)
    def bodyAsString = bodyStream.text

    // JSON Parsing
    def jsonParser = new JsonSlurper()
    def json = jsonParser.parseText(bodyAsString)

    // extract the Access Token
    def accessToken = json.access_token

    // Save the token as property
    message.setProperty("AccessToken", accessToken)

  // Set the Authorization Header
    def headers = message.getHeaders()
    headers.put("Authorization", "Bearer " + accessToken)
    message.setHeaders(headers)

    return message
}
