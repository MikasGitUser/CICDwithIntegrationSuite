import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;

def Message processData(Message message) {

    def service = ITApiFactory.getApi(PartnerDirectoryService.class, null); 
    if (service == null){
        throw new IllegalStateException("Partner Directory Service not found");
    }
    
    //Get RCVPRN from the Property
    def headers = message.getHeaders(); 
    def Snd_Pid = headers.get("Idoc_Sender");
    def Rec_Pid = headers.get("Idoc_Receiver");
    
    if (Rec_Pid == null){
        throw new IllegalStateException("No Receiver Available");   
    }
    //Set EDI Receiver Identifier 
    def EDI_ReceiverID = service.getAlternativePartnerId("EDIFACT", "ZZ" , Rec_Pid);
    if (EDI_ReceiverID == null){
        throw new IllegalStateException("NO EDIFACT Identifier found for Partner" + Rec_Pid);   
    }
    message.setHeader("EDI_ReceiverID", EDI_ReceiverID);
    
    //Set EDI Sender Identifier 
    def EDI_SenderID = service.getAlternativePartnerId("EDIFACT", "ZZ" , Snd_Pid);
    if (EDI_SenderID == null){
        throw new IllegalStateException("NO EDIFACT Identifier found for " + Snd_Pid);   
    }
    message.setHeader("EDI_ReceiverID", EDI_ReceiverID);
    message.setHeader("EDI_SenderID", EDI_SenderID);
    
    def IFlowEndpoint = headers.get("Idoc_MesTyp") + "_" + headers.get("Idoc_IdocTyp")
    if(headers.get("Idoc_Extension")==null || headers.get("Idoc_Extension") == "")
        message.setHeader("IFlowEndpoint", IFlowEndpoint)
    else
        message.setHeader("IFlowEndpoint", IFlowEndpoint+"_"+headers.get("Idoc_Extension"))
    return message;
}
